# Delivery validation — 15 September 2026

## Automated checks

**18 tests passed, 0 failed.** The tests ran against a new in-memory PostgreSQL database through the actual HTTP API.

- Setup/authentication guards and exact decimal tax arithmetic.
- Purchase stock, weighted-average cost and supplier balances.
- Sale idempotency, receipt totals and split tenders.
- Full rollback when one invoice line has insufficient stock.
- Concurrent checkout of the last unit: exactly one succeeds.
- Credit sale, partial return and customer receipt reconciliation.
- Quotations leave stock and receivables unchanged.
- Duplicate import rows roll back the entire import; successful CSV import preserves opening stock.
- Cashier cost masking and blocked financial-report/backup access.
- Logout revokes the server session.
- Sales report and GST-register queries execute.
- Invoice cancellation restores stock once.
- Online-order cancellation restores stock and status cannot regress.
- Stock-movement records reject updates.
- Full database backup loads into a second PostgreSQL instance and preserves sales records.

## Build and browser

- Vite production build passed. Barcode generation is a separate lazy-loaded chunk; Vite reports its size warning (about 944 KB before gzip).
- Viewed setup/login and the populated dashboard in the in-app browser.
- Signed into a separate synthetic demo store; verified the dashboard's 28-day metrics, low-stock list and category/bestseller displays.
- Completed a two-item checkout through the UI. Receipt INV-000138 displayed ₹313.00 total, ₹299.43 taxable amount, ₹6.79 CGST and ₹6.78 SGST; the basket reset after success.
- Demo data persisted across a server restart. The user's separate store data was not used for tests or included in the source ZIP.

## Not exercised against external services

No WhatsApp/SMS messages were sent. Provider delivery, real OTP receipt, physical receipt printers, production server PostgreSQL, government GST filing and an online payment gateway were not verified. The delivered GST module is a register, not a filing integration. Scanned PDF OCR is not included. See README for accounting and deployment scope.

## Bulk / storefront update

- 23 automated checks pass, including customer/supplier balances, duplicate batch replay, stock expiry batches, negative-stock rollback, all eight CSV/XLSX template downloads, unauthorized access, malformed CSV rejection, tax-exclusive product display totals, delivery charges and pincode rejection.
- Browser checked the customer catalog, search for milk, basket quantity and the change from ₹28 pickup to ₹53 including ₹25 delivery in the isolated sample store. Phone layout checked at 390×844; desktop layout checked at the normal viewport.
- Build succeeds. Barcode library remains a lazy-loaded large chunk.
- Existing local database data was preserved. Sample-only browser checks use a separate demo database.
- External GitHub publishing, Render provisioning and app-owned Google OAuth upload have not been exercised because the needed repository/host/app credentials are not available. The Drive connector source package upload is separate from the runtime backup feature.

## Password accounts and one shared stock database

25 automated checks pass. Added coverage for registration validation, duplicate usernames, preventing mobile-based account claiming, wrong-password rejection, order ownership, server-side logout, password change/revocation, auto-listing bulk products and simultaneous POS/online orders competing for one remaining unit.
